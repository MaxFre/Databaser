package uppgift;


public class Main {
	public static void main(String[] args) {
		Gui run = new Gui();		
//		GuiBesökare run2 = new GuiBesökare();
		
		
	}
}
